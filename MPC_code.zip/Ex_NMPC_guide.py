# -*- coding: utf-8 -*-
"""
Created on Tue Jan 12 12:11:54 2016

@author: marcovaccari
"""
from casadi import *
from casadi.tools import *
from matplotlib import pylab as plt
import math
import scipy.linalg as scla
import numpy as np
from Utilities import*


# NOC discretization parameters

Nsim = 201 # Simulation length

N = 50    # Horizon

h = 0.2 # Time step

########## Symbolic variables #####################
xp = SX.sym("xp", 3) # process state vector       #
x = SX.sym("x", 3)  # model state vector          #
u = SX.sym("u", 2)  # control vector              #
y = SX.sym("y", 2)  # measured output vector      #
d = SX.sym("d", 2)  # disturbance                 #
###################################################

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
## PLANT
def User_fxp_Cont(x,t,u):
    """
    SUMMARY:
    It constructs the function fx_p for the non-linear case
        
    SYNTAX:
    assignment = User_fxp_Cont(x,t,u)
        
    ARGUMENTS:
    + x         - State variable     
    + t         - Current time
    + u         - Input variable  
        
    OUTPUTS:
    + fx_p      - Non-linear plant function
    """     
    F0 = if_else(t <= 5, 0.1, if_else(t<= 15, 0.15, if_else(t<= 25, 0.08, 0.1)))
    T0 = 350  # K
    c0 = 1.0  # kmol/m^3
    r = 0.219 # m
    k0 = 7.2e10 # min^-1
    EoR = 8750 # K
    U0 = 915.6*60/1000  # kJ/min*m^2*K
    rho = 1000.0 # kg/m^3
    Cp2 = 0.239 # kJ/kg
    DH = -5.0e4 # kJ/kmol
    Ar = math.pi*(r**2)
    kT0 = k0*exp(-EoR/T0)

    fx_p = vertcat\
    (\
    F0*(c0 - x[0])/(Ar *x[2]) - kT0*exp(-EoR*(1.0/x[1]-1.0/T0))*x[0], \
    F0*(T0 - x[1])/(Ar *x[2]) -DH/(rho*Cp2)*kT0*exp(-EoR*(1.0/x[1]-1.0/T0))*x[0] + \
    2*U0/(r*rho*Cp2)*(u[0] - x[1]), \
    (F0 - u[1])/Ar\
    )    
  
    return fx_p

Mx = 10 # Number of elements in each time step  

def User_fyp(x,t):

    fy_p = vertcat\
    (\
    x[0],\
    x[2] \
    )
    
    return fy_p

R_wn = 1e-7*np.array([[1.0, 0.0], [0.0, 1.0]]) # Output white noise covariance matrix
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

## Disturbance model
offree = "nl" # set "lin"/"nl" to have a linear/non linear disturbance model. "no" means no disturbance model will be implmented
#Cd = DM.zeros(y.size1(),d.size1())
#Bd = np.array([[1., 0.],  [0. , 0.],   [0.0, 1.]])

    
def User_fxm_Cont(x,u,d,t):
    F0 = d[1]
    T0 = 350  # K
    c0 = 1.0  # kmol/m^3
    r = 0.219 # m
    k0 = 7.2e10 # min^-1
    EoR = 8750 # K
    U0 = 915.6*60/1000  # kJ/min*m^2*K
    rho = 1000.0 # kg/m^3
    Cp2 = 0.239 # kJ/kg
    DH = -5.0e4 # kJ/kmol
    Ar = math.pi*(r**2)
    kT0 = k0*exp(-EoR/T0)

    x_model = vertcat\
    (\
    F0*(c0 - x[0])/(Ar *x[2]) - kT0*exp(-EoR*(1.0/x[1]-1.0/T0))*x[0], \
    F0*(T0 - x[1])/(Ar *x[2]) -DH/(rho*Cp2)*kT0*exp(-EoR*(1.0/x[1]-1.0/T0))*x[0] + \
    2*U0/(r*rho*Cp2)*(u[0] - x[1]), \
    (F0 - u[1])/Ar\
    )    
    return x_model

def User_fym(x,d,t):    
    fy_model = vertcat\
                (\
                x[0],\
                x[2]\
                )   
    return fy_model
    

#
Mx = 10 # Number of elements in each time step 
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

# Initial conditions
x0_p = np.array([0.874317, 325, 0.6528]) # plant
x0_m = np.array([0.874317, 325, 0.6528]) # model
u0 = np.array([300.157, 0.1])

## Input bounds
umin = np.array([295, 0.00])
umax = np.array([305, 0.25])

## State bounds
xmin = np.array([0.0, 315, 0.50])
xmax = np.array([1.0, 375, 0.75])

# Output bounds
ymin = np.array([0.0, 0.5])
ymax = np.array([1.0, 1.0])

## Disturbance bounds
dmin = -100*np.ones((d.size1(),1))
dmax = 100*np.ones((d.size1(),1))

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
## Setpoints

def defSP(t):
    xsp = np.array([0.0, 0.0, 0.0]) # State setpoints  
    ysp = np.array([0.874317, 0.6528]) # Output setpoint
    usp = np.array([300.157, 0.1]) # Control setpoints
    return [ysp, usp, xsp]
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
## OBJECTIVE FUNCTION

## Steady-state optimization 
Qss = np.array([[10.0, 0.0], [0.0, 1.0]]) #Output matrix
Rss = np.array([[0.0, 0.0], [0.0, 0.0]]) # Control matrix

## Dynamic optimization 
Q = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]])
R = np.array([[0.1, 0.0], [0.0, 0.1]])
 
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
## Estimator
#### Extended Kalman filter tuning params ###################################
ekf = True # Set True if you want the Extended Kalman filter
Qx_kf = 1.0e-5*np.eye(x.size1())
Qd_kf = np.eye(d.size1())
Q_kf = scla.block_diag(Qx_kf, Qd_kf)
R_kf = 1.0e-4*np.eye(y.size1())
P0 = 1*np.ones((x.size1()+d.size1(),x.size1()+d.size1())) 