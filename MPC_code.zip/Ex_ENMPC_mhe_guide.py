# -*- coding: utf-8 -*-
"""
Created on Tue Jan 12 12:11:54 2016

@author: marcovaccari
"""
from casadi import *
from casadi.tools import *
from matplotlib import pylab as plt
import math
import scipy.linalg as scla
import numpy as np
from Utilities import*


# NOC discretization parameters

Nsim = 21 # Simulation length

N = 25    # Horizon

h = 2.0   # Time step

########## Symbolic variables #####################
xp = SX.sym("xp", 2) # process state vector       #
x = SX.sym("x", 2)  # model state vector          #
u = SX.sym("u", 1)  # control vector              #
y = SX.sym("y", 2)  # measured output vector      #
d = SX.sym("d", 2)  # disturbance                 #
###################################################
mhe_mod = 'on'
N_mhe = 10 # Horizon lenght
mhe_up = 'smooth' #Updating method for prior weighting and x_bar
#estimating = True

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
StateFeedback = True # Set to True if you have all the states measured 
Sol_itmax = 200

OCPTracking = False

cA0 = 1.0  # kmol/m^3 ???
V = 1.0 # m^3 ????
k1 = 1. # min^-1
k2 = 0.05 # min^-1
alfa = 1. # reactant price
beta = 4. # product price
gammak2 = 1.
gammak1 = 1.
## PLANT

# To set if the plant is non-linear
def User_fxp_Cont(xp,t,u):
    """
    SUMMARY:
    It constructs the function fx_p for the non-linear case
    
    SYNTAX:
    assignment = deffxp(t)
  
    ARGUMENTS:
    + t             - Variable that indicate the current iteration
    
    OUTPUTS:
    + fx_p      - Non-linear plant function     
    """ 

     ## Example from Douglas Allan
    
    fx_p = vertcat(u[0]*(cA0 - xp[0])/V - k1*xp[0], \
                           -u[0]*xp[1]/V + k1*xp[0] - k2*xp[1])
    
    
    return fx_p

G_wn = 1e-2*np.array([[1.0, 0.0], [0.0, 1.0]]) # State white noise matrix
Q_wn = 1e-1*np.array([[1.0, 0.0], [0.0, 1.0]]) # State white noise covariance matrix
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

## Disturbance model
offree = "lin" 
Bd = np.zeros((d.size1(),d.size1()))
Cd = np.eye(d.size1())


# To set if the model is non-linear

#from MPC_code import gammak2                     
def User_fxm_Cont(x,u,d,t):
    """
    SUMMARY:
    It constructs the function fx_model for the non-linear case
    
    SYNTAX:
    assignment = fx_model(x,u,d,t)
  
    ARGUMENTS:
    + x,u,d         - State, input and disturbance variable
    + t             - Variable that indicate the real time
    
    OUTPUTS:
    + x_model       - Non-linear model function     
    """ 

     ## Example from Douglas Allan
    
    x_model = vertcat(u[0]*(cA0 - x[0])/V - gammak1*k1*x[0], \
                       -u[0]*x[1]/V + gammak1*k1*x[0] - gammak2*k2*x[1])
#    
#    x_model = vertcat(u[0]*(cA0 - x[0])/V - (k1+d[0])*x[0], \
#                       -u[0]*x[1]/V + (k1+d[0])*x[0] - (gammak2*k2+d[1])*x[1])
    return x_model
    
#
Mx = 10 # Number of elements in each time step 
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

# Initial conditions
x0_p = vertcat(0.9, 0.1) # plant
x0_m = vertcat(1.2, 0.5) # model
u0 = vertcat(0.)

## Input bounds
umin = [0.00]
umax = [2.0]

## State bounds
xmin = vertcat(0.00, 0.00)
xmax = vertcat(1.00, 1.00)



# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
## Setpoints

def defSP(t):
    """
    SUMMARY:
    It constructs the setpoints vectors for the steady-state optimisation 
    
    SYNTAX:
    assignment = defSP(t)
  
    ARGUMENTS:
    + t             - Variable that indicates the current time
    
    OUTPUTS:
    + ysp, usp, xsp - Input, output and state setpoint values      
    """ 
    xsp = np.array([0.0, 0.0]) # State setpoints  
    ysp = np.array([0.0, 0.0]) # Output setpoint
    usp = np.array([0.0]) # Control setpoints
    
    return [ysp, usp, xsp]
    
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
## OBJECTIVE FUNCTION

cA0 = 1.0  # kmol/m^3 
alfa = 1. # reactant price
beta = 4. # product price

## Steady-state optimization 
def User_fssobj(x,u,y,xsp,usp,ysp):
    obj = u[0]*(alfa*cA0 - beta*y[1])
    return obj
    
## Dynamic optimization 
def User_fobj_Cont(x,u,y,xs,us,ys):
    obj = u[0]*(alfa*cA0 - beta*y[1]) 
    return obj

# Terminal weight
def User_vfin(x):
    vfin = mtimes(x.T,mtimes(2000,x)) 
    return vfin

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
## Estimator

#############################################################################

if mhe_mod == 'off':
    #### Extended Kalman filter tuning params ###################################
    ekf = True # Set True if you want the Kalman filter
    nx = x.size1()
    ny = y.size1()
    nd = d.size1()
    Qx_kf = 1.0e-8*DM.eye(nx)
    Qd_kf = 1.0*DM.eye(nd)
    Q_kf = DM(scla.block_diag(Qx_kf, Qd_kf))
    R_kf = 1.0e-8*DM.eye(ny)
    P0 = 1.0e-8*DM.eye(nx+nd)  
    nameoutputfile = 'ekf'
else:
    
    #### Moving Horizon Estimation params ###################################
    mhe = True # Set True if you want the MHE
    N_mhe = 10 # Horizon lenght
    mhe_up = 'smooth' # Updating method for prior weighting and x_bar
    nx = x.size1()
    ny = y.size1()
    nd = d.size1()
    w = SX.sym("w", nx+nd)  # state noise  
    P0 = np.eye(nx+nd)
    x_bar = np.row_stack((np.atleast_2d(x0_m).T,np.zeros((nd,1))))
    
    # Defining the state map
    def User_fx_mhe_Cont(x,u,d,t,w):
        
        x_model = vertcat(u[0]*(cA0 - x[0])/V - k1*x[0], \
                       -u[0]*x[1]/V + k1*x[0] - k2*x[1])
        
        return x_model
    
    # Defining the MHE cost function
    def User_fobj_mhe(w,v,t):

        Q = np.eye(nx+nd)
        R = np.eye(ny)
        fobj_mhe = 0.5*(xQx(w,inv(Q))+xQx(v,inv(R)))
        
        return fobj_mhe